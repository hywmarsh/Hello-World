﻿Public Class frmHelloWorld

    Private Sub frmHelloWorld_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblOutput.Text = "Hello World"
        MsgBox("Hello World")
    End Sub
End Class
